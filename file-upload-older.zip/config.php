<?php 
//functions 
/*
 * NMT @ adsoft
 * 
 * to do: list config limits
 * upload progress?
 * translate phrases?
 * drop-down selectable folder to upload in?
 * browse folder contents & manipulate files?
 *  
 * 
 */
function formatBytes($bytes, $precision = 2) {
	$units = array('B', 'Kb', 'Mb', 'Gb', 'Tb');

	$bytes = max($bytes, 0);
	$pow = floor(($bytes ? log($bytes) : 0) / log(1024));
	$pow = min($pow, count($units) - 1);

	// Uncomment one of the following alternatives
	$bytes /= pow(1024, $pow);
	// $bytes /= (1 << (10 * $pow));

	return round($bytes, $precision) . ' ' . $units[$pow];
}

function logError($errArray) {
	ob_start();
	var_dump($errArray);	
	$outStringVar = ob_get_contents();	
	
	$fp=fopen('upload_errors.html','a+');
	
	fwrite($fp, $outStringVar.'<br />===================================<br />');
	fclose($fp);
	
	ob_end_clean();
}
// variables
//$upload_dir = "/var/www/vhosts/partyline.be/xml-proxyclick/new/"; //@partyline
$upload_dir = 'uploaded/'; //@local
$max_file_size = '10485760'; // maximum file size, in bytes
$allowed_types = array('text/xml');  //file type as seen by apache
?>